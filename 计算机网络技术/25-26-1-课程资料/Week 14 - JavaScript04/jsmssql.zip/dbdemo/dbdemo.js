// mssql模块的简单使用
// 导入数据库支持库
var sql = require('mssql');

// 数据库连接对象的配置
// 设置用户名，密码，服务器名称
// 数据库名，端口，一些连接池的设置
var dbConfig = {
    user: 'GISUSER',
    password: 'GISuser123',
    server: '10.129.85.254',
    database: 'sport',
    port: 1433,
    options: {
        encrypt: false, // 是否启用加密连接（Azure SQL 必需）
        connectTimeout: 3000 // 连接超时时间
    },
    pool: {
        max: 10, // 最大连接数
        min: 0,        
        idleTimeoutMillis: 30000 // 连接空闲超时
    }
};

async function getAllstuinfos(){
    try{
        // 配置信息的导入
        await sql.connect(dbConfig);

        const result = await sql.query("SELECT * FROM dbo.stuinfo")
        console.log('查询结果:', result.recordset)

    }catch (err) {
    console.error('数据库操作失败:', err)
  } finally {
    // 关闭所有连接
    await sql.close()
  }
}
// 查询所有的学生信息
getAllstuinfos();


// 查询所有的学生信息连接池版本：
function getAllstuinfosv2() {
    // 配置信息的导入
    var conn = new sql.ConnectionPool(dbConfig);

    var req = new sql.Request(conn);
    // 开始连接，而后检测是否连接成功
    conn.connect(function (err) {
        if (err) {
            console.log(err);
            return;
        }
        // 开始查询stuinfo表
        req.query("SELECT * FROM dbo.stuinfo", function (err, recordset) {
            if (err) {
                // 有错误时则报错，没有错误，则打印出结果数据
                console.log(err);
                return;
            }
            else {
                console.log(recordset);
            }
            conn.close();
        });
    });
}
// 查询所有的学生信息（连接池版本）
// getAllstuinfosv2();

