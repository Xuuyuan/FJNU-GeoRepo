// 载入mssql库
var mssql = require('mssql');
// 信息提示一下：
console.log("load dbjs ");
// 用于返回的变量的入口：用于module.exports输出。
var db = {};
// 数据库的连接配置：
var config = {
  user: 'GISUSER',
  password: 'GISuser123',
  server: '10.129.85.254',
  database: 'sport',
  port: 1433,
  options: {
    encrypt: false, // Use this if you're on Windows Azure
    connectTimeout: 3000
  },
  pool: {
    min: 0,
    max: 10,
    idleTimeoutMillis: 3000
  }
};


//执行sql,返回数据.
db.sql = function (sql, callBack) {
  //  sql参数：sql语句, callback参数：回调函数名称 
  
  // 数据库的连接设置
  var connection = mssql.connect(config, function (err) {
    // 如果连接出错，则报错：
    if (err) {
      console.log(err);
      return;
    }
    // 接下来的内容为prepareStatement预编译框架，可以比较好的避免或防止sql注入。
    // 获得数据连接对象，创建一个预处理语句
    var ps = new mssql.PreparedStatement(connection);
    // 调用prepare获得连接对象，而后所有操作独占此数据连接进行操作
    // 调用unprepare后，则释放此数据库连接。
    // 先预编译sql内容。
    ps.prepare(sql, function (err) {
      if (err) {
        console.log(err);
        return;
      }
    // 开始执行语句
    ps.execute('', function (err, result) {
      // 如果出错，则报错。
      if (err) {
        console.log(err);
        // callback(err, null);
        return;
      }
      ps.unprepare(function (err) {
        if (err) {
          console.log(err);
          callback(err, null);
          return;
        }
        // 返回结果result：
        callBack(err, result);
      });
    });
    });
  });
};
// 模块的输出
module.exports = db;