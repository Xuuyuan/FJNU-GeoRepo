//引入express
const express = require("express"); 
//引入path
const path = require("path");		
// 引入自定义的数据库处理模块mssqldb
var db = require('./mssqldb');

//创建服务器
const app = express();
// 用于解析客户端post进来的参数信息的模块。
const bodyParser = require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

//监听端口设置
app.listen(8080, function () {
  console.log("http://127.0.0.1:8080");
});


//设置静态文件目录
app.use(express.static("public"));
// 配置应用程序的默认路由，即采用"/"时，指向访问的目录。
// __dirname，指前执行文件的目录的绝对路径
// path.join：把路径进行连接，获得真实路径。
app.use("/", express.static(path.join(__dirname, "public")));


// 测试程序，测试网络服务是否成功。
app.get('/api/test', function (req, res) {
  res.json({ code: 200, msg: "服务器搭建成功！" });
})

// 查询学生人数功能。
app.get('/api/dbcount', function (req, res) {
  var strresult = ''
  db.sql('select * from stuinfo', function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    console.log('学生人数为 :', result.recordset.length);
    strresult = '学生人数为  :' + result.recordset.length;
    res.json({ code: 200, msg: strresult });
  });

})

// 返回所有学生信息的功能。
app.get('/api/fullstuinfo', function (req, res) {
  var strresult = ''

  db.sql('select * from stuinfo', function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    // 用于存放结果的列表对象
    var resultlist = []

    // 遍历返回的结果，设计一个对象，存放结果记录信息

    for (var i = 0, l = result.recordset.length; i < l; i++) {
      var obj = {}
      // 从结果recordset中解析出对象信息，根据不同字段信息，存给obj对象。
      obj['stuid'] = result.recordset[i].stuid
      obj['specialty'] = result.recordset[i].specialty
      obj['name'] = result.recordset[i].name
      // 把对象obj放到结果列表中。
      resultlist.push(obj)
    }
    // 返回结果列表对象
    res.json({ code: 200, data: resultlist });
  });

})

// 根据专业来查询学生信息
// 测试函数：http://127.0.0.1:8080/api/querybyspecility/地理信息系统
app.get('/api/querybyspecility/:specility', function (req, res) {
  // api链接中：specility表示在URL中附加的参数信息，会保存在req.params中。
  var strresult = ''
  // 由请求中查到需要查询的专业变量信息。
  var strspecility = req.params.specility
  // 构建查询字符串
  var querystr = "select * from stuinfo where specialty = '" + strspecility + "'";
  db.sql(querystr, function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    // 用于存放结果的列表对象
    var resultlist = []
    // 遍历返回的结果，设计一个对象，存放结果记录信息
    for (var i = 0, l = result.recordset.length; i < l; i++) {
      var obj = {}
      obj['stuid'] = result.recordset[i].stuid
      obj['specialty'] = result.recordset[i].specialty
      obj['name'] = result.recordset[i].name
      resultlist.push(obj)

    }
    // 返回结果列表对象
    res.json({ code: 200, data: resultlist });
  });

})

// 查询数据库中学生信息中的专业的信息
// 测试函数：http://127.0.0.1:8080/api/stuspecialty
app.get('/api/stuspecialty', function (req, res) {
  var strresult = ''
  // 查询专业字段specialty的唯一值。
  db.sql('select distinct specialty from stuinfo', function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    // 由于结果均为字符，因此组成一个数组，将结果放到数组中返回。
    var resultlist = []

    for (var i = 0, l = result.recordset.length; i < l; i++) {
      var tempstr = result.recordset[i].specialty

      resultlist.push(tempstr)

    }   
    // 将结果放到data中，以json方式返回。
    res.json({ code: 200, data: resultlist });
  });
})

// 接收客户端传来的新建用户的信息
/* 测试信息：在REST Client中测试
POST http://127.0.0.1:8080/api/addstu HTTP/1.1
content-type: application/json

{
    "name": "张明锋",
    "sex": "男",
    "grade": "2016",
    "stuid" :"109122016091",
    "specialty": "地理信息系统"
}
*/
app.post('/api/addstu', function (req, res) {
  // 临时测试看是否有结果过来
  // console.log(req.body)
  // 用于保存结果信息的变量
  var msg = "success"
  // 保存客户端传过来的信息的变量
  tempstuinfo = req.body
  // 根据客户端传过来的信息，动态生成查询字符串 
  var tempsqlhead = "insert into stuinfo(name,sex,grade,stuid,specialty) values "
  // 注意：由于数据类型基本为字符类型，因此需要在变量上附加上单引号
  var tempsql = tempsqlhead + "('" + tempstuinfo.name + "','" + 
  tempstuinfo.sex + "','" + tempstuinfo.grade + "','" + tempstuinfo.stuid + "','" + 
  tempstuinfo.specialty + "')"
  // 可用于临时输出，查看组合后的字符串结果。
  // console.log(tempsql)

  // 开始进行查询
  db.sql(tempsql, function (err, result) {
    if (err) {
      // 如果出错，则输出错误信息，并返回给客户端
      console.log(err);

      msg = err.message;
      res.json({
        code: 200,
        msg: msg
      });
      return
    }
    // 检测一下是否影响到的结果记录为1，如果是，则成功，返回信息。
    if (result.rowsAffected == 1) {
      msg = "success"
    } else {
      msg = "fail"
    }
    res.json({
      code: 201,
      msg: msg
    });
  });

});

// 根据iD号来进行查询
// 测试函数：http://127.0.0.1:8080/api/querybyid/109122013010
app.get('/api/querybyid/:id', function (req, res) {
  // api链接中：id表示在URL中附加的参数信息，会保存在req.params中。
  var strresult = ''
  // 由请求中查到需要查询的ID信息。
  var strid = req.params.id
  db.sql("select * from stuinfo where stuid = '" + strid + "'", function (err, result) {
    if (err) {
      console.log(err);
      return;
    }
    var resultlist = []
    // 如果没有查到数据，则返回空数据
    if (result.recordset.length == 0) {
      res.json({ code: 200, data: [] });
      return
    }
    // 如果有数据，则为第一条，因为是使用ID号来进行查询。
    var obj = {}
    obj['stuid'] = result.recordset[0].stuid
    obj['specialty'] = result.recordset[0].specialty
    obj['name'] = result.recordset[0].name
    obj['sex'] = result.recordset[0].sex
    obj['grade'] = result.recordset[0].grade


    res.json({ code: 200, data: [obj] });
  });

})

// 接收客户端传来的新建用户的信息
/* 测试信息：在REST Client中测试
POST http://127.0.0.1:8080/api/editstu HTTP/1.1
content-type: application/json

{
    "name": "张明锋2",
    "sex": "男",
    "grade": "2016",
    "stuid" :"109122016091",
    "specialty": "地理信息系统"
}
*/
app.post('/api/editstu', function (req, res) {
  // 临时测试看是否有结果过来
  // console.log(req.body)
  // 用于保存结果信息的变量
  var msg = "success"
  // 保存客户端传过来的信息的变量
  tempstuinfo = req.body
  // 修改具体sql代码来保存编辑的学生信息，并检测。
  // 根据客户端传过来的信息，动态生成查询字符串 
  var tempsqlhead = "update stuinfo set name=$name,sex=$sex,grade=$grade,specialty=$specialty  where stuid="
  // 注意：由于数据类型基本为字符类型，因此需要在变量上附加上单引号
  var tempsql = tempsqlhead + "'" + tempstuinfo.stuid + "'"
  // 使用js中的字符串替换方法，将查询语句中的$符号后面变量进行更换。
  tempsql = tempsql.replace("$name", "'" + tempstuinfo.name + "'")
  tempsql = tempsql.replace("$sex", "'" + tempstuinfo.sex + "'")
  tempsql = tempsql.replace("$grade", "'" + tempstuinfo.grade + "'")
  tempsql = tempsql.replace("$specialty", "'" + tempstuinfo.specialty + "'")
  // 可用于临时输出，查看组合后的字符串结果。
  // console.log(tempsql)

  // 开始进行查询
  db.sql(tempsql, function (err, result) {
    if (err) {
      // 如果出错，则输出错误信息，并返回给客户端
      console.log(err);

      msg = err.message;
      res.json({
        code: 200,
        msg: msg
      });
      return
    }
    // 检测一下是否影响到的结果记录为1，如果是，则成功，返回信息。
    if (result.rowsAffected == 1) {
      msg = "success"
    } else {
      msg = "fail"
    }
    res.json({
      code: 200,
      msg: msg
    });
  });


});

// 根据iD号来进行删除查询
// 测试函数：http://127.0.0.1:8080/api/delbyid/109122016091
app.get('/api/delbyid/:id', function (req, res) {
  // api链接中：id表示在URL中附加的参数信息，会保存在req.params中。
  var strresult = ''
  // 由请求中查到需要查询的ID信息。
  var strid = req.params.id
  db.sql("delete from stuinfo where stuid = '" + strid + "'", function (err, result) {
    if (err) {
      console.log(err);
      msg = err.message;
      res.json({
        code: 200,
        msg: msg
      });
      return
    }
    // 检测一下是否影响到的结果记录为1，如果是，则成功，返回信息。
    if (result.rowsAffected == 1) {
      msg = "success"
    } else {
      msg = "fail"
    }
    res.json({
      code: 200,
      msg: msg
    });
  });
});




