// express路由示范程序
var express = require('express');
var app = express();

const port = 8081

// express 静态文件范例：

// 把public目录作为存放静态文件的位置，
// 并且根目录直接指向这个public目录
app.use("/",express.static('public'))

// 处理客户端访问主页时，默认路径下返回静态文件home.html的信息。
app.get('/',  (req, res) => {  
  res.sendFile( __dirname  + "/public/home.html" );
  
})


var server = app.listen(port, function () {
 
  console.log(`服务运行在端口${port}`);
 
})

