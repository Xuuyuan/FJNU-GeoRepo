// express路由示范程序
var express = require('express');
var app = express();

const port = 8081

// 路由路径范例：
// get范例：
// 处理客户端访问主页时，默认路径下返回的信息。
app.get('/',  (req, res) => {  
  res.send('Hello GISers');  
})

// 匹配：http://localhost:8081/about
app.get('/about',(req, res) => {  
  res.send('about 信息');  
})

// post范例：
app.post('/', (req, res) => {  
  res.send('receive GISers post request');  
})
// all范例：
app.all("/all",(req, res) =>{
  res.send("receive GISers all request")
})

// 路由参数部分：
app.get('/users/:userId/', (req, res) => {
  res.send("收到用户：" + req.params['userId']+ "的信息");
})

// 匹配：http://localhost:8081/users/zmf/books/testbook
app.get('/users/:userId/books/:bookId', (req, res) => {
  res.send("你要的是用户：" + req.params['userId']+ "的 " +
    req.params['bookId']+ "书");
})



var server = app.listen(port, function () {
 
  console.log(`服务运行在端口${port}`);
 
})

