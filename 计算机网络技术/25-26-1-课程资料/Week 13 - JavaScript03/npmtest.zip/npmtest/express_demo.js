// express示范程序
var express = require('express');
var app = express();

const port = 8081
// 处理客户端访问主页时，默认路径下返回的信息。
app.get('/', function (req, res) {
   res.send('Hello GISers');
})

var server = app.listen(port, function () {
 
  console.log(`服务运行在端口${port}`);
 
})