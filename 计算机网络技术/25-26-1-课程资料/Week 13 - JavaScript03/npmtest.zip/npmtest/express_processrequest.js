// express路由示范程序
var express = require('express');
var app = express();

const port = 8081;

// express 静态文件范例：

// 把public目录作为存放静态文件的位置，
// 并且根目录直接指向这个public目录
app.use("/",express.static('public'));

// 需要载入，以解析post传过来的信息
// 解析application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

// 处理客户端访问主页时，默认路径下返回静态文件home.html的信息。
app.get('/',  (req, res) => {  
  res.sendFile( __dirname  + "/public/home.html" );
  
});
// 用于测试的数据
const jsondata = [
  {
    "title": "计算机网络技术",
    "teacher": "张明锋"
  },
  {
    "title": "java",
    "teacher": "赵珊珊"
  },
  {
    "title": "DEM",
    "teacher": "吴勇"
  }
];

// 处理/courselist请求，将测试数据返回
app.get('/courselist',(req,res)=>{
  res.json(jsondata)
});

// 处理post请求
app.post('/process_post',(req,res)=>{

  let teacherstr = ''
  // 遍历数据，找到符合请求中的课程，获得老师名字
  jsondata.forEach(element => {
    if (element.title == req.body.coursesel)
    {
      teacherstr = element.teacher
    }  
        
  });
  // 构建json对象
  let responsejson = {
    "name" : req.body.name,
    "select":req.body.coursesel,
    "teacher": teacherstr
  };
  // 将json对象转换成字符串
  let txtreturn = responsejson.name +"选择了" + 
  responsejson.select +",授课老师为：" + 
  responsejson.teacher
  // 返回字符串信息
  res.send(txtreturn)

});

var server = app.listen(port, function () {
 
  console.log(`服务运行在端口${port}`);
 
});

