﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication31
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("请输入第一个数：");
            double num1=double.Parse(Console.ReadLine());
            Console.WriteLine("请输入第二个数：");
            double num2 = double.Parse(Console.ReadLine());
            Console.WriteLine("请输入符号'+,-,*,/'");

            string flag = Console.ReadLine();
            double result = 0;

            if (flag == "+")
            {
                result = num1 + num2;
                
            }
            else if (flag == "-")
            {
                result = num1 - num2;
            }
            else if (flag == "*")
            {
                result = num1 * num2;
                
            }
            else if (flag == "/")
            {
                result = num1 / num2;
            }
            Console.WriteLine(result.ToString());
            Console.ReadLine();
        }
    }
}
