﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication98
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int temp = int.Parse(textBox2.Text);
            if (comboBox1.Text == "大写字符")
            {
                for (int i = 0; i <= temp; i++)
                {
                    int c = r.Next(65, 91);
                    textBox1.Text = textBox1.Text + ((char)c).ToString();
                }
            }
            else if (comboBox1.Text == "小写字符")
            {
                for (int i = 0; i <= temp; i++)
                {
                    int c = r.Next(97, 123);
                    textBox1.Text = textBox1.Text + ((char)c).ToString();
                }
            }
            else if (comboBox1.Text == "混合字符")
            {
                for (int i = 0; i <= temp; i++)
                {
                    Random r1 = new Random();
                    int ran = r1.Next(0, 2);
                    if (ran == 0)
                    {
                        int c = r.Next(97, 123);
                        textBox1.Text = textBox1.Text + ((char)c).ToString();
                    }
                    else
                    {
                        int c = r.Next(65, 91);
                        textBox1.Text = textBox1.Text + ((char)c).ToString();
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s = "";
            if (checkBox1.Checked==true)
            {

                //for (int i = 0; i < textBox1.Text.Length; i++)
                //{
                   
                //    s=s+char.ToUpper(textBox1.Text[i]);
                    
                //}
                //textBox1.Text = s;
                //
                textBox1.Text = textBox1.Text.ToUpper();

            }
            else if (checkBox2.Checked == true)
            {
                for (int i = 0; i < textBox1.Text.Length; i++)
                {
                    
                    s = s + char.ToLower(textBox1.Text[i]);
                 

                }
                textBox1.Text = s;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            char temp = char.ToUpper(textBox3.Text[0]);
            double num=0;
            string s = textBox1.Text.ToUpper();
            for (int i = 0; i<s.Length; i++)
            {
                if (s[i] == temp)
                {
                    num++;
                }

            }
            textBox4.Text = num.ToString();
            //textBox5.Text = num / textBox1.Text.Length+"%";
            textBox5.Text = string.Format("{0:F2}%", num / textBox1.Text.Length);
        }
    }
}
